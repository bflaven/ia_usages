import dash
import dash_bootstrap_components as dbc

print(dash.__version__)
print(dbc.__version__)
