// import { NextResponse } from "next/server";
// import { fiefAuth } from "../../../helpers/fief";

// @TODO Implement a proper Fief implementation in Next 14
export async function GET() {
    // const currentUser = await fiefAuth.currentUser();
    return Response.json({});
}
