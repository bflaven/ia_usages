export { default } from "@/components/loader"; // Adjust the relative path accordingly
