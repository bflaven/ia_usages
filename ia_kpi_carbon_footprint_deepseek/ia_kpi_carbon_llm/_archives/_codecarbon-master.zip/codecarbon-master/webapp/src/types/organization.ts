export interface Organization {
    id: string;
    name: string;
    description: string;
}
