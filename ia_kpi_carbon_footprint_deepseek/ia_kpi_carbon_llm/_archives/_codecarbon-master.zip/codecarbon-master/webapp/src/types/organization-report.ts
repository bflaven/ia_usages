export interface OrganizationReport {
    name: string;
    emissions: number;
    energy_consumed: number;
    duration: number;
}
