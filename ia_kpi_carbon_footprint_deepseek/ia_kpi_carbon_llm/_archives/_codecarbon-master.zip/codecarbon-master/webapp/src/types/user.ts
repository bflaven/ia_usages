export interface User {
    id: string;
    email: string;
    name: string;
    organizations: string[];
    is_active: boolean;
}
