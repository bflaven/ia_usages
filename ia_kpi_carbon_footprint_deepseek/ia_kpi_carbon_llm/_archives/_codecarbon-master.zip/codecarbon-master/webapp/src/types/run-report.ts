export interface RunReport {
    run_id: string;
    emissions: number;
    timestamp: string;
    energy_consumed: number;
    duration: number;
}
